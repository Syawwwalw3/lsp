<?php

$page = "Pemesanan Tiket";

require 'functions.php';
session_start();

if(!isset($_SESSION["username"])){
    echo "
    <script type='text/javascript'>
        alert('Silahkan login terlebih dahulu, ya!');
        window.location = '../auth/login/index.php';
    </script>
    ";
}

$orderTiket = query("SELECT * FROM order_tiket")

?>

<?php require '../../layouts/sidebar_admin.php'; ?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="../../assets/style/main.css">
</head>
<body>
    <div class="content">
    <h1>Halo, <?= $_SESSION["nama_lengkap"]; ?></h1>
    <h1>Data Pemesanan Tiket</h1>
    <table border="1" cellpadding="10" cellspacing="0">
    <tr>
        <th>Nomor Order</th>
        <th>Struk</th>
        <th>Status</th>
        <th>Opsi</th>
    </tr>
    <?php foreach($orderTiket as $data) : ?>
        <tr>
            <td><?= $data["id_order"]; ?></td>
            <td><?= $data["struk"]; ?></td>
            <td>
            <?php 
                if($data["status"] == "Proses"){
                    ?>
                    <a href="update_status.php?id=<?= $data["id_order"]; ?>" style="color: blue; text-decoration: none;">Proses</a>
                    <?php
                } else if($data["status"] == "Berhasil"){
                    ?>
                    <a href="" style="color: green; text-decoration: none;">Berhasil</a>
                    <?php
                } else if($data["status"] == "Gagal"){
                    ?>
                    <a href="" style="color: red; text-decoration: none;">Gagal</a>
                    <?php
                }
            ?>
            </td>
            <td>
                <?php if ($data["status"] == "Proses"){
                    ?>
                    <a href="verif.php?id=<?= $data["id_order"]; ?>">Verifikasi</a>
                    <a href="reject.php?id=<?= $data["id_order"]; ?>">Reject</a>
                    <?php }else if($data["status"] == "Berhasil" || $data["status"] == "Gagal"){
                        ?>
                    <a href="hapus.php?id=<?= $data["id_order"]; ?>">Hapus</a>
                    <?php    
                } ?>
            </td>
        </tr>
    <?php endforeach; ?>
</table>
        </body>
        </html>