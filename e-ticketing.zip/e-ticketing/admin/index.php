<?php
$page= "dasboard";
session_start();

if(!isset($_SESSION["username"])){
    echo "
    <script type='text/javascript'>
        alert('Silahkan login terlebih dahulu, ya!');
        window.location = '../auth/login/index.php';
    </script>
    ";
}


?>

<?php require '../layouts/sidebar_admin.php'; ?>
<style>
   body{ 
    background-image: url('../../assets/images/bandara-terindah.jpg');}
    
</style>
<h1>Halo, <?= $_SESSION["nama_lengkap"]; ?></h1>

